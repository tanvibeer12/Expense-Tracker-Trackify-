import { useState } from 'react';
import { Target, Plus, Trash2, AlertCircle } from 'lucide-react';
import type { Budget, Expense } from '../App';

interface BudgetTrackerProps {
  budgets: Budget[];
  expenses: Expense[];
  onUpdateBudget: (category: string, limit: number) => void;
  onDeleteBudget: (category: string) => void;
  categories: string[];
}

export function BudgetTracker({
  budgets,
  expenses,
  onUpdateBudget,
  onDeleteBudget,
  categories,
}: BudgetTrackerProps) {
  const [selectedCategory, setSelectedCategory] = useState('');
  const [budgetLimit, setBudgetLimit] = useState('');
  const [showForm, setShowForm] = useState(false);

  const currentMonth = new Date().getMonth();
  const currentYear = new Date().getFullYear();

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!selectedCategory || !budgetLimit || parseFloat(budgetLimit) <= 0) {
      return;
    }

    onUpdateBudget(selectedCategory, parseFloat(budgetLimit));
    setSelectedCategory('');
    setBudgetLimit('');
    setShowForm(false);
  };

  const getCategorySpending = (category: string) => {
    return expenses
      .filter(expense => {
        const expenseDate = new Date(expense.date + 'T00:00:00');
        return expense.category === category &&
               expenseDate.getMonth() === currentMonth &&
               expenseDate.getFullYear() === currentYear;
      })
      .reduce((sum, expense) => sum + expense.amount, 0);
  };

  const availableCategories = categories.filter(
    cat => !budgets.find(b => b.category === cat)
  );

  return (
    <div className="bg-white rounded-lg shadow-md p-6">
      <div className="flex items-center justify-between mb-4">
        <h2 className="text-xl font-semibold text-gray-800 flex items-center gap-2">
          <Target className="size-5 text-indigo-600" />
          Budget Goals
        </h2>
        {!showForm && (
          <button
            onClick={() => setShowForm(true)}
            className="text-indigo-600 hover:text-indigo-700 p-1"
            aria-label="Add budget"
          >
            <Plus className="size-5" />
          </button>
        )}
      </div>

      {showForm && (
        <form onSubmit={handleSubmit} className="mb-4 p-4 bg-indigo-50 rounded-lg space-y-3">
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">
              Category
            </label>
            <select
              value={selectedCategory}
              onChange={(e) => setSelectedCategory(e.target.value)}
              className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-indigo-500 focus:border-transparent"
              required
            >
              <option value="">Select category</option>
              {availableCategories.map(cat => (
                <option key={cat} value={cat}>{cat}</option>
              ))}
            </select>
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">
              Monthly Limit ($)
            </label>
            <input
              type="number"
              value={budgetLimit}
              onChange={(e) => setBudgetLimit(e.target.value)}
              placeholder="0.00"
              step="0.01"
              min="0.01"
              className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-indigo-500 focus:border-transparent"
              required
            />
          </div>

          <div className="flex gap-2">
            <button
              type="submit"
              className="flex-1 bg-indigo-600 text-white py-2 px-4 rounded-lg hover:bg-indigo-700 transition-colors text-sm"
              disabled={availableCategories.length === 0}
            >
              Set Budget
            </button>
            <button
              type="button"
              onClick={() => {
                setShowForm(false);
                setSelectedCategory('');
                setBudgetLimit('');
              }}
              className="px-4 py-2 text-gray-600 hover:bg-gray-100 rounded-lg transition-colors text-sm"
            >
              Cancel
            </button>
          </div>
        </form>
      )}

      {budgets.length === 0 && !showForm ? (
        <p className="text-gray-500 text-sm text-center py-4">
          Set budget goals for your categories
        </p>
      ) : (
        <div className="space-y-4">
          {budgets.map(budget => {
            const spent = getCategorySpending(budget.category);
            const percentage = (spent / budget.limit) * 100;
            const isOverBudget = spent > budget.limit;

            return (
              <div key={budget.category} className="border-b border-gray-100 pb-4 last:border-0">
                <div className="flex items-center justify-between mb-2">
                  <div className="flex items-center gap-2">
                    <span className="font-medium text-gray-700 text-sm">
                      {budget.category}
                    </span>
                    {isOverBudget && (
                      <AlertCircle className="size-4 text-red-500" />
                    )}
                  </div>
                  <button
                    onClick={() => onDeleteBudget(budget.category)}
                    className="text-gray-400 hover:text-red-600 transition-colors"
                    aria-label="Delete budget"
                  >
                    <Trash2 className="size-4" />
                  </button>
                </div>
                
                <div className="space-y-1">
                  <div className="flex justify-between text-xs text-gray-600">
                    <span>
                      ${spent.toFixed(2)} / ${budget.limit.toFixed(2)}
                    </span>
                    <span className={isOverBudget ? 'text-red-600 font-medium' : ''}>
                      {percentage.toFixed(0)}%
                    </span>
                  </div>
                  <div className="w-full bg-gray-200 rounded-full h-2 overflow-hidden">
                    <div
                      className={`h-2 rounded-full transition-all ${
                        isOverBudget
                          ? 'bg-red-500'
                          : percentage > 80
                          ? 'bg-yellow-500'
                          : 'bg-green-500'
                      }`}
                      style={{ width: `${Math.min(percentage, 100)}%` }}
                    />
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      )}
    </div>
  );
}
