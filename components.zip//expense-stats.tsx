import { DollarSign, TrendingUp, Calendar, TrendingDown, PieChart } from 'lucide-react';
import type { Expense, Budget } from '../App';

interface ExpenseStatsProps {
  expenses: Expense[];
  budgets: Budget[];
}

export function ExpenseStats({ expenses, budgets }: ExpenseStatsProps) {
  const totalExpenses = expenses.reduce((sum, expense) => sum + expense.amount, 0);
  
  const today = new Date().toISOString().split('T')[0];
  const todayExpenses = expenses
    .filter(expense => expense.date === today)
    .reduce((sum, expense) => sum + expense.amount, 0);

  const currentMonth = new Date().getMonth();
  const currentYear = new Date().getFullYear();
  const monthlyExpenses = expenses
    .filter(expense => {
      const expenseDate = new Date(expense.date + 'T00:00:00');
      return expenseDate.getMonth() === currentMonth && 
             expenseDate.getFullYear() === currentYear;
    })
    .reduce((sum, expense) => sum + expense.amount, 0);

  // Calculate average daily spending
  const uniqueDates = new Set(expenses.map(e => e.date));
  const averageDaily = uniqueDates.size > 0 ? totalExpenses / uniqueDates.size : 0;

  // Category breakdown
  const categoryTotals = expenses.reduce((acc, expense) => {
    acc[expense.category] = (acc[expense.category] || 0) + expense.amount;
    return acc;
  }, {} as Record<string, number>);

  // Calculate total budget
  const totalBudget = budgets.reduce((sum, budget) => sum + budget.limit, 0);
  const budgetRemaining = totalBudget - monthlyExpenses;

  return (
    <div className="space-y-4">
      {/* Summary Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        <div className="bg-gradient-to-br from-indigo-500 to-indigo-600 rounded-xl shadow-lg p-5 text-white">
          <div className="flex items-center justify-between mb-2">
            <p className="text-indigo-100">Total Expenses</p>
            <DollarSign className="size-8 opacity-80" />
          </div>
          <p className="text-3xl font-bold">
            ${totalExpenses.toFixed(2)}
          </p>
          <p className="text-indigo-100 text-sm mt-1">
            {expenses.length} transaction{expenses.length !== 1 ? 's' : ''}
          </p>
        </div>

        <div className="bg-gradient-to-br from-green-500 to-green-600 rounded-xl shadow-lg p-5 text-white">
          <div className="flex items-center justify-between mb-2">
            <p className="text-green-100">This Month</p>
            <Calendar className="size-8 opacity-80" />
          </div>
          <p className="text-3xl font-bold">
            ${monthlyExpenses.toFixed(2)}
          </p>
          {totalBudget > 0 && (
            <p className="text-green-100 text-sm mt-1">
              {budgetRemaining >= 0 
                ? `$${budgetRemaining.toFixed(2)} left` 
                : `$${Math.abs(budgetRemaining).toFixed(2)} over`}
            </p>
          )}
        </div>

        <div className="bg-gradient-to-br from-purple-500 to-purple-600 rounded-xl shadow-lg p-5 text-white">
          <div className="flex items-center justify-between mb-2">
            <p className="text-purple-100">Today</p>
            <TrendingUp className="size-8 opacity-80" />
          </div>
          <p className="text-3xl font-bold">
            ${todayExpenses.toFixed(2)}
          </p>
          <p className="text-purple-100 text-sm mt-1">
            Avg: ${averageDaily.toFixed(2)}/day
          </p>
        </div>

        <div className="bg-gradient-to-br from-orange-500 to-orange-600 rounded-xl shadow-lg p-5 text-white">
          <div className="flex items-center justify-between mb-2">
            <p className="text-orange-100">Categories</p>
            <PieChart className="size-8 opacity-80" />
          </div>
          <p className="text-3xl font-bold">
            {Object.keys(categoryTotals).length}
          </p>
          <p className="text-orange-100 text-sm mt-1">
            {Object.keys(categoryTotals).length > 0 
              ? `Top: ${Object.entries(categoryTotals).sort(([, a], [, b]) => b - a)[0][0]}`
              : 'No data'}
          </p>
        </div>
      </div>

      {/* Category Breakdown */}
      {Object.keys(categoryTotals).length > 0 && (
        <div className="bg-white rounded-xl shadow-lg p-6">
          <h3 className="font-semibold text-gray-800 mb-4 flex items-center gap-2">
            <TrendingDown className="size-5 text-indigo-600" />
            Spending by Category
          </h3>
          <div className="space-y-4">
            {Object.entries(categoryTotals)
              .sort(([, a], [, b]) => b - a)
              .map(([category, amount]) => {
                const percentage = (amount / totalExpenses) * 100;
                const budget = budgets.find(b => b.category === category);
                
                return (
                  <div key={category}>
                    <div className="flex justify-between text-sm mb-2">
                      <span className="text-gray-700 font-medium">{category}</span>
                      <div className="text-right">
                        <span className="font-semibold text-gray-900">
                          ${amount.toFixed(2)}
                        </span>
                        <span className="text-gray-500 ml-2">
                          ({percentage.toFixed(1)}%)
                        </span>
                        {budget && (
                          <span className="text-xs text-gray-500 ml-2">
                            / ${budget.limit.toFixed(2)}
                          </span>
                        )}
                      </div>
                    </div>
                    <div className="relative w-full bg-gray-200 rounded-full h-3 overflow-hidden">
                      <div
                        className={`h-3 rounded-full transition-all ${
                          budget && amount > budget.limit
                            ? 'bg-gradient-to-r from-red-500 to-red-600'
                            : 'bg-gradient-to-r from-indigo-500 to-indigo-600'
                        }`}
                        style={{ 
                          width: budget 
                            ? `${Math.min((amount / budget.limit) * 100, 100)}%`
                            : `${percentage}%` 
                        }}
                      />
                    </div>
                  </div>
                );
              })}
          </div>
        </div>
      )}
    </div>
  );
}
