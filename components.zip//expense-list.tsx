import { Trash2, Calendar, Tag, Edit2 } from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import type { Expense } from '../App';

interface ExpenseListProps {
  expenses: Expense[];
  onDeleteExpense: (id: string) => void;
  onEditExpense: (expense: Expense) => void;
}

export function ExpenseList({ expenses, onDeleteExpense, onEditExpense }: ExpenseListProps) {
  if (expenses.length === 0) {
    return (
      <div className="bg-gray-50 rounded-lg p-12 text-center">
        <p className="text-gray-500 text-lg">No expenses found. Start tracking your spending!</p>
      </div>
    );
  }

  const formatDate = (dateString: string) => {
    const date = new Date(dateString + 'T00:00:00');
    return date.toLocaleDateString('en-US', { 
      month: 'short', 
      day: 'numeric', 
      year: 'numeric' 
    });
  };

  return (
    <div className="space-y-3 max-h-[600px] overflow-y-auto pr-2">
      <AnimatePresence>
        {expenses.map(expense => (
          <motion.div
            key={expense.id}
            initial={{ opacity: 0, y: -10 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, x: -100 }}
            transition={{ duration: 0.2 }}
            className="flex items-center justify-between p-4 bg-gradient-to-r from-gray-50 to-white rounded-lg hover:shadow-md transition-all border border-gray-100"
          >
            <div className="flex-1 min-w-0">
              <h3 className="font-medium text-gray-900 truncate">{expense.description}</h3>
              <div className="flex items-center gap-4 mt-1 text-sm text-gray-600 flex-wrap">
                <span className="flex items-center gap-1">
                  <Tag className="size-4" />
                  {expense.category}
                </span>
                <span className="flex items-center gap-1">
                  <Calendar className="size-4" />
                  {formatDate(expense.date)}
                </span>
              </div>
            </div>
            
            <div className="flex items-center gap-3 ml-4">
              <span className="text-xl font-semibold text-indigo-600 whitespace-nowrap">
                ${expense.amount.toFixed(2)}
              </span>
              <button
                onClick={() => onEditExpense(expense)}
                className="text-blue-600 hover:text-blue-700 hover:bg-blue-50 p-2 rounded-lg transition-colors"
                aria-label="Edit expense"
              >
                <Edit2 className="size-5" />
              </button>
              <button
                onClick={() => onDeleteExpense(expense.id)}
                className="text-red-600 hover:text-red-700 hover:bg-red-50 p-2 rounded-lg transition-colors"
                aria-label="Delete expense"
              >
                <Trash2 className="size-5" />
              </button>
            </div>
          </motion.div>
        ))}
      </AnimatePresence>
    </div>
  );
}
